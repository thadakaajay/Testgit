<!DOCTYPE html>
<html lang="en">
<head>
  
  <title>Web Development Blog</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>

<body>
	<div class="page-header">
  		<h1>Introduction to Bootstrap</h1>
  		<img src="https://images.pexels.com/photos/326424/pexels-photo-326424.jpeg" class="img-fluid w-100 p-3" alt="Responsive image">
	</div>
	<div class=“container-fluid”> 
		<p> Get started with <mark>Bootstrap</mark>, the world’s most popular framework for building responsive, mobile-first sites, with Bootstrap <abbr title="Content Delivery Network">CDN</abbr> and a template starter page. </p>

		<p>According to the official website, Bootstrap is the most popular HTML, CSS, and JS framework for developing responsive, mobile first projects on the web. Sounds great! Now how do I use it? It would be easy to send you over to their Getting Started page and call it a day. Their setup guide is indeed a host of useful information — links to CDNs, explanations on how to install with Bower, npm, and Composer, information on integration with Autoprefixer and LESS, a bunch of templates, licenses, and translations — but you could read this blog here instead for a better and easier understanding.</p>
		<span class="glyphicon glyphicon-pencil"></span>

		<p class="text-center">The list below shows the different version of Bootstrap so far. <span class="glyphicon glyphicon-list-alt"></span></p>

		<ul class="list-group">
		  <li class="list-group-item">v1.x</li>
		  <li class="list-group-item">v2.x</li>
		  <li class="list-group-item">v3.x</li>
		  <li class="list-group-item">v4.x</li>
		</ul>

		<p class="text-center bg-info"> The main features of bootstrap is, it is very simple and easy to use, huge JavaScript plugins are available, easily design mobile friendly website.</p>

	</div>

	
	<div class="container-fluid">   
	  <h2></h2>
	  <table class="table table-bordered table-striped">
	    <thead>
	      <tr >
	        <th>Features of Bootstrap</th>
	      </tr>
	    </thead>
	    <tbody>
	      <tr>
	        <td>Easy to Use</td>
	      </tr>
	      <tr>
	        <td>Mobile Friendly</td>
	      </tr>
	      <tr>
	        <td>Prestyled Components</td>
	      </tr>
	    </tbody>
	  </table>
	</div>
	<div class="container-fluid"
		<p class="text-left">Lets take a look at the components of bootstrap:</p>
		<h1>CSS<span class="badge badge-secondary">Quoted</span></h1>
		<p class="text-justify">Copy-paste the stylesheet link into your head before all other stylesheets to load our CSS.</p>
		<h2>JS <span class="badge badge-secondary">Quoted</span></h2>
		<p class="text-justify">Many of our components require the use of JavaScript to function. Specifically, they require jQuery, Popper.js, and our own JavaScript plugins. Place the following scripts near the end of your pages, right before the closing bodytag, to enable them. jQuery must come first, then Popper.js, and then our JavaScript plugins.We use jQuery’s slim build, but the full version is also supported.</p>
	</div>
	<div class="card">
		  <div class="card-header">Author</div>
		  <div class="card-body">The article was contributed by katesmith12</div>
		  <a href="https://www.sitesbay.com/bootstrap/bootstrap-features-of-bootstrap" class="card-footer btn btn-outline-primary stretched-link">View References</a>
	</div>
	<!-- Footer -->
	<footer class="page-footer font-small indigo">

	  <!-- Copyright -->
	  <div class="footer-copyright text-center py-3">This is the footer section where you can put the address and copyright details. © 2018 Copyright: 
	    <a href="https://simplilearn.net/"> Simplilearn</a>
	  </div>
	  <!-- Copyright -->

	</footer>
	<!-- Footer -->

<script src="https://code.jquery.com/jquery-3.3.2.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>

